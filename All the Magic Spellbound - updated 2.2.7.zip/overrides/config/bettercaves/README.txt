This directory is for adding YUNG's Better Caves configurations specific to certain dimensions.
Starting with Minecraft 1.16, this directory serves as the base directory for all future versions.

For example, to add a dimension-specific config to the Nether in 1.16, you need to first create a
directory named 1_16 in this folder.
(This will be created for you the first time you run YUNG's Better Caves for 1.16).
Then, in the 1_16 folder, create a config file named DIM_minecraft-the_nether.toml.

NOTE -- YOU MUST HAVE THE DIMENSIONS YOU WANT TO USE WHITELISTED (OR HAVE GLOBAL WHITELISTING ENABLED)
IN THE BASE CONFIG FILE FOR THIS TO WORK.

FOR MORE INFORMATION, CHECK OUT THE WIKI -- https://github.com/yungnickyoung/YUNGs-Better-Caves/wiki